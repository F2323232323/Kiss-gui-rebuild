
package com.haubutz.kissgui;

import android.app.Activity;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("KISS GUI Rebuild bereit – USB-OTG aktiviert!");
        setContentView(tv);
    }
}
